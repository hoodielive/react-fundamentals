import {
    MyLibrary, 
    otherLibraryFunction} from './libFile1'
} 

var obj = {MyLibrary: function() {}, otherLibraryFunction: function() {}} 
