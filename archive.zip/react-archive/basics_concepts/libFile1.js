export function MyLibrary() {
    console.log('inside my Library')
}; 

export function otherLibraryFunction() { 

    console.log('other library function') 
}


// if you want everything exported just add: default export function (like commonjs) 
