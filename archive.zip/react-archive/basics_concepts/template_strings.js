var name = 'law'

console.log('Hello, my name is' + name) 
console.log(`Hello, my name is ${name}`) 


