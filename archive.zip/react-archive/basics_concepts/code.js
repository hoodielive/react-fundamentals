const toLowerCase = input => {
    const output = [] 
    for (let i = 0; i < input.length; i++) {
        outpush.push(input[i].toLowerCase()) 
    }
    return output
}; 
