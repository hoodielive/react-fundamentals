
ReactDOM.render(
    document.getElementById('root')
); 
