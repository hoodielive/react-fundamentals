
ReactDOM.render(

    <h1>Howdy, there!</h1>
    
    document.getElementById('root')
); 
